<?php
/**
 * Permanent redirects for pages that were removed (1.3.11).
 * Only fires when no published page lives at the old address, so a page can be brought back
 * simply by publishing it again. Lives in the theme so it moves to Bluehost with the site.
 *
 * @package Solevo
 */

defined( 'ABSPATH' ) || exit;

function solevo_redirects() {
	return array(
		// Steph, 25 Oct: pelvic floor is no longer offered as a service.
		'physio/pelvic-floor-physiotherapy' => 'physio',
		// Steph, 28 Oct: pelvic floor treatment is not advertised.
		'conditions/bladder-leakage-incontinence' => 'conditions',
		// 1.4.0 (Steph's feedback, 3 Nov): no pregnancy or postnatal physio, no pregnancy classes,
		// Over 50s merged into Seniors, Private Pilates dropped. Postnatal physio goes straight to /physio (no chain).
		'physio/pregnancy-physiotherapy'    => 'physio',
		'physio/postnatal-physiotherapy'    => 'physio',
		'pilates/pregnancy-pilates'         => 'pilates',
		'pilates/over-50s-fitness'          => 'pilates/seniors',
		'pilates/private-pilates'           => 'pilates',
		// Hayo, 3 Nov: Mums and Bubs points at the postnatal class page.
		'pilates/mums-and-bubs'             => 'pilates/postnatal-pilates',
		// 1.4.6 (Steph's feedback, 4 Nov): spinal stenosis page dropped; osteoporosis moved to its own URL.
		'conditions/spinal-stenosis'        => 'conditions/sciatica',
		'conditions/osteoporosis-pilates'   => 'conditions/osteoporosis',
		// 1.4.7: holding redirect while the shin splints draft waits for Steph and Emma.
		// Stops by itself the moment the page is published.
		'conditions/shin-splints'           => 'conditions/foot-ankle',
		// 1.4.14 (Steph, 6 Nov): disc injuries are covered on the lower back pain page.
		'conditions/herniated-disc'         => 'conditions/lower-back-pain',
	);
}

add_action( 'template_redirect', function () {
	if ( ! is_404() && ! ( is_singular( 'page' ) && 'publish' !== get_post_status() ) ) {
		return;
	}
	$path = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	$map  = solevo_redirects();
	if ( ! isset( $map[ $path ] ) ) {
		return;
	}
	$page = get_page_by_path( $path, OBJECT, 'page' );
	if ( ! $page || 'publish' !== $page->post_status ) {
		wp_safe_redirect( home_url( '/' . $map[ $path ] ), 301, 'Solevo' );
		exit;
	}
} );
